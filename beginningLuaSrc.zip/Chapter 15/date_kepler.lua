cgilua.contentheader("text", "plain")
cgilua.put(os.date())
