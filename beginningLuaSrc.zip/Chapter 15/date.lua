io.write('Content-Type: text/plain\n\n', os.date(), '\n')
