dofile("show")

screen.clear()
ObjectShow({gui = gui, screen = screen, bin = bin,
  bit = bit, buffer = buffer}, "Plua")
