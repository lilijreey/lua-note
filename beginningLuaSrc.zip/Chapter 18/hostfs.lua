screen.clear()
print("Hello from HostFS")
gui.event()
