-- A short script (for use as a luac test).

function Greet(Name)
  print("Hello, " .. Name .. ".")
end

Greet("whoever you are")
