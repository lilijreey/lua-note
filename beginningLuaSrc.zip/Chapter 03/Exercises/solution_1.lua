function TypedToString(Val)
  return type(Val) .. ": " .. tostring(Val)
end
