function SumProd(A, B)
  return A + B, A * B
end
