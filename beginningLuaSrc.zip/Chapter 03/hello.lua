-- This is the first file-based example in the book.
print("Hello, world!")
