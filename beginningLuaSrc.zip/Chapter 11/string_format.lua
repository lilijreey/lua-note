io.write(string.format("Color: #%02X%02X%02X\n", 198, 239, 247))
