print(string.char(76, 117, 97))
