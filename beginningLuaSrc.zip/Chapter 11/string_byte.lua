print(string.byte("Lua", 1, 3))
