local Base, Exp = 0, 10
local Pow = math.pow(Base, Exp)
io.write(Base, " ^ ", Exp, " = ", Pow == 0 and "nothing at all" or Pow, "\n")
-- With a friendly tipnod of the hat to Ian Anderson
