print(nil, 1 == 1, 1 + 1, "one", function() end, {})
