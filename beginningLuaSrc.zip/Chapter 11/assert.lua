Val = 12
assert(type(Val) == "boolean", "Expecting boolean value")
