error("Printer on fire.")
