package.cpath = "./?.so;./?.dll"
require "stacklook"

print("stack.look", stack.look(1, 2, 3, 4, 5, 6, 7))
