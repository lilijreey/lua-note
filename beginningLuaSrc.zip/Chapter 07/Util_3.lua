function string.quote(Str)
  return string.format("%q", Str)
end

return string
