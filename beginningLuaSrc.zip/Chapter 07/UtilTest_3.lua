require("Util")
print(string.quote('Natty "Pathfinder" Bumppo'))
