require("Util")
print(Quote('Natty "Pathfinder" Bumppo'))
