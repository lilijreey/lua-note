require("Util")
print(Util.Quote('Natty "Pathfinder" Bumppo'))
