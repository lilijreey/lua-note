Utility = require("Util")
print(Utility.Quote('Natty "Pathfinder" Bumppo'))
