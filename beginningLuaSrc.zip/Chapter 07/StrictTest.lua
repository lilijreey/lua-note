require "strict"

local function Test()
  A = 2
  B = 3
end

A = 1
Test()
