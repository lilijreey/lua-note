for N = 10, 2, -2 do
  print(N)
end
